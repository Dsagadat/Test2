#include <stdio.h>
#include <stdlib.h>
#include "L1.h"
//��������� ������� ���������� �������� �� ������������� ��������
//Made by Ashurov_AA
void push(struct Node** head_ref,
	double new_data, double new_data2)
{

	struct Node* new_node =
		(struct Node*)malloc(sizeof(struct Node));


	new_node->data = new_data;
	new_node->data2 = new_data2;

	new_node->next = (*head_ref);
	(*head_ref) = new_node;
}


void insertAfter(struct Node* prev_node,
	double new_data, double new_data2)
{
	struct Node* new_node =
		(struct Node*)malloc(sizeof(struct Node));

	if (prev_node == NULL)
	{
		printf("the given previous node cannot be NULL\n");
		return;
	}

	new_node->data = new_data;
	new_node->data2 = new_data2;

	new_node->next = prev_node->next;


	prev_node->next = new_node;
}

void append(struct Node** head_ref,
	double new_data, double new_data2)
{
	struct Node* new_node =
		(struct Node*)malloc(sizeof(struct Node));

	struct Node* last = *head_ref;


	new_node->data = new_data;
	new_node->data2 = new_data2;

	new_node->next = NULL;


	if (*head_ref == NULL)
	{
		*head_ref = new_node;
		return;
	}


	while (last->next != NULL)
		last = last->next;


	last->next = new_node;
	return;
}


void printList(struct Node* node)
{
	while (node != NULL)
	{
		printf(" %lf %lf\n", node->data, node->data2);
		node = node->next;
	}
}

void freeList(struct Node* node)
{
	struct Node* tmp = NULL;
	while (node != NULL)
	{
		tmp = node->next;
		free(node);
		node = tmp;
	}
}
