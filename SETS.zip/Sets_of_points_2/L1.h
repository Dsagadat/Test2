#pragma once
struct Node
{
	double data;
	double data2;
	struct Node* next;
};
void printList(struct Node* node);
void push(struct Node** head_ref, double new_data, double new_data2);
void insertAfter(struct Node* prev_node, double new_data, double new_data2);
void append(struct Node** head_ref, double new_data, double new_data2);
int scan_p(struct Node** node, char* name, const char* name2);
void freeList(struct Node* node);
int det(struct Node* node);
int compare(double x, double y);
void double_gen(struct Node** node);
