#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "L1.h"
#define N 4
//��������� ������� ���������� �������� �� ������������� ��������
//Made by Ashurov_AA
void double_gen(struct Node** node) {
      /* ������� ������� ������� ������ ������������ ����� ������ 1000 */
	int i = 0;
	int t = 0;
    
	double r_min = -1e20;
	double r_max = 1e20;
    double x;
    double y;
    double x0;
    double y0;
    int f1 = 1;
    FILE* b = fopen("b.txt", "w");
    srand(time(NULL));
	for (i = 0; i < N; i++)
	{
		t = rand();
        x = ((((double)t) / RAND_MAX) * (r_max - r_min) + r_min);
        t = rand();
        y = ((((double)t) / RAND_MAX) * (r_max - r_min) + r_min);
            if (f1 == 1)
		{
			x0 = x;
			y0 = y;
			f1 = 0;
		}
		append(node, x,y);
        fprintf(b, "%lf %lf\n", x, y);
        
	}
	fprintf(b, "%lf %lf\n", x0, y0);
	fclose(b);
}
int scan_p(struct Node** node, char* name, const char* name2)
{
	double x;
	double y;
	double x0;
	double y0;
	int f1 = 1;

	FILE* fptr = fopen(name, "r");
	FILE* b = fopen(name2, "w");
	if (!fptr)
	{
		printf("ERROR_OPEN_FILE\n");
		return -1;
	}

	while (fscanf(fptr, "%lf", &x) == 1 &&
		fscanf(fptr, "%lf", &y) == 1)
	{
		if (f1 == 1)
		{
			x0 = x;
			y0 = y;
			f1 = 0;
		}
		append(node, x, y);
		fprintf(b, "%lf %lf\n", x, y);
	}
	fprintf(b, "%lf %lf\n", x0, y0);
	if (!feof(fptr))
	{
		fclose(fptr);
		return -1;
	}
	fclose(fptr);
	return 0;
}


int compare(double x, double y)
{
	if (x > y) return 1;
	if (x < y) return -1;
	return 0;
}
int det(struct Node* node)
{
	double x1, x2, x3, y1, y2, y3, x0, y0, y10 , x10;
	int answ = 0;
	int l = 0, r = 0;
	if ((node->next == NULL) || (node->next->next == NULL))
		return answ;
	answ = 1;
	x0 = node->data;
	y0 = node->data2;
	x10 = node->next->data;
	y10 = node->next->data2;
	while ((node->next->next != NULL))
	{
		x1 = node->data;
		y1 = node->data2;
		x2 = node->next->data;
		y2 = node->next->data2;
		x3 = node->next->next->data;
		y3 = node->next->next->data2;
		if ((x3 - x1) * (y2 - y1) - (y3 - y1) * (x2 - x1) > 0)
		{
			if (l == 0 && r == 0)
				r = 1;
			else if (l != 0)
			{
				answ = 0;
				break;
			}
		}
		else if ((x3 - x1) * (y2 - y1) - (y3 - y1) * (x2 - x1) < 0)
		{
			if (l == 0 && r == 0)
				l = 1;
			else if (r != 0)
			{
				answ = 0;
				break;
			}
		}

		node = node->next;

	}
	x1 = x2;
	x2 = x3;
	y1 = y2;
	y2 = y3;
	x3 = x0;
	y3 = y0;
	if ((x3 - x1) * (y2 - y1) - (y3 - y1) * (x2 - x1) > 0)
	{
		if (l == 0 && r == 0)
			r = 1;
		else if (l != 0)
		{
			answ = 0;

		}
	}
	else if ((x3 - x1) * (y2 - y1) - (y3 - y1) * (x2 - x1) < 0)
	{
		if (l == 0 && r == 0)
			l = 1;
		else if (r != 0)
		{
			answ = 0;

		}
	}
	else
	{
		answ = 0;

	}
	x1 = x2;
	x2 = x3;
	y1 = y2;
	y2 = y3;
	x3 = x10;
	y3 = y10;
	if ((x3 - x1) * (y2 - y1) - (y3 - y1) * (x2 - x1) > 0)
	{
		if (l == 0 && r == 0)
			r = 1;
		else if (l != 0)
		{
			answ = 0;

		}
	}
	else if ((x3 - x1) * (y2 - y1) - (y3 - y1) * (x2 - x1) < 0)
	{
		if (l == 0 && r == 0)
			l = 1;
		else if (r != 0)
		{
			answ = 0;

		}
	}
	else
	{
		answ = 0;

	}
	return answ;
}
